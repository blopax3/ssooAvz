/*
    mem_dinamica.h
*/

#ifndef MEM_DINAMICA_H     // Si no está definido ...
#define MEM_DINAMICA_H     // ... lo definimos, y además:

typedef int entero;        // Sinónimo del tipo int
void mem_dinamica (void);  // Declaración de una función
extern int k;              // Declaración (¡sólo declaración!)

#endif                     // final del bloque #ifndef - #endif
